/* ══════════════════════════════════════════════════════════
   TIPOFF FANTASY — Regular Season (LAB)

   A self-contained season-long mode: commissioner picks roster size
   (8–12), everyone snake-drafts, then each week is a head-to-head
   matchup scored with Sleeper-style LOCK-IN:

     • 5 starting slots: G, G, F, F, UTIL (F accepts F or C; UTIL any)
     • After a starter plays, you may LOCK that game's fantasy score
       into the slot, or PASS and wait for a later game.
     • One locked game per slot per week. A lock is final.
     • A slot that is never locked gets its most recent game
       (a DNP counts as 0). No game at all = 0.
     • Only games played while the player sat in that slot count.
       Bench games never count. You can swap a slot until it locks.

   ISOLATION
     Nothing here reads or writes the tournament state in app.js.
     Storage key: 'tipoff-season-v1' (localStorage). The shape is
     deliberately plain JSON so it can move to Firestore later as a
     single document per league.

   DATA
     Offline lab build: weekly games are SIMULATED from each player's
     real 2025-26 per-game averages (data/players.js). Swap
     generateWeekGames() for a real box-score feed later — nothing
     else needs to change, since everything downstream only reads
     state.games[week][playerId] = [{ day, fpts, line, dnp }].
══════════════════════════════════════════════════════════ */
(function (window, document) {
  'use strict';

  var STORE_KEY = 'tipoff-season-v1';
  var DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  var DAYS_FULL = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  var SLOTS = ['G', 'G', 'F', 'F', 'UTIL'];
  var WEIGHTS = { points: 1, rebounds: 1.2, assists: 1.5, steals: 2, blocks: 2 };
  var BOT_NAMES = [
    'Full Court Press', 'Backdoor Cutters', 'Glass Cleaners', 'Mid-Major Mayhem',
    'Bracket Busters', 'Zone Breakers', 'Pick & Pop', 'And-One Army',
    'Buzzer Beaters', 'Paint Protectors', 'Fast Break FC'
  ];

  var state = null;
  var ui = { tab: 'week', swapSlot: null, filterPos: 'ALL', search: '', toast: '', stamp: null, setup: null };
  var root = null;

  // ── Utilities ───────────────────────────────────────────
  function mulberry32(a) {
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      var t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  function hashStr(s) {
    var h = 2166136261;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }
  function rngFor(key) { return mulberry32(hashStr(String(state.league.seed) + '|' + key)); }
  function gauss(r) {
    var u = 1 - r(), v = r();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function f1(n) { return (Math.round(n * 10) / 10).toFixed(1); }
  function save() { try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); } catch (e) { /* lab: ignore */ } }
  function load() {
    try { var raw = localStorage.getItem(STORE_KEY); return raw ? JSON.parse(raw) : null; } catch (e) { return null; }
  }
  function sessionName() {
    try { var s = JSON.parse(localStorage.getItem('mmfantasy-session') || 'null'); return (s && s.name) || 'You'; } catch (e) { return 'You'; }
  }

  // ── Player pool ─────────────────────────────────────────
  var POOL = null, BY_ID = null;
  function pool() {
    if (POOL) return POOL;
    var seen = {};
    POOL = [];
    (window.MM_PLAYERS || []).forEach(function (p) {
      if (seen[p.id]) return;
      seen[p.id] = true;
      var st = p.stats || {};
      var avg = {
        points: +st.points || 0, rebounds: +st.rebounds || 0, assists: +st.assists || 0,
        steals: +st.steals || 0, blocks: +st.blocks || 0
      };
      // True freshmen with no prior line: give a modest prior so a top
      // recruit isn't treated as a permanent zero. Deterministic per id.
      if (p.hasStats === false) {
        var r = mulberry32(hashStr(p.id));
        avg = { points: 4 + r() * 6, rebounds: 1.5 + r() * 3, assists: 0.5 + r() * 1.5, steals: 0.4 + r() * 0.5, blocks: 0.2 + r() * 0.5 };
      }
      POOL.push({
        id: p.id, name: p.name, college: p.college, pos: p.position || 'G', cls: p.cls,
        fresh: p.hasStats === false, avg: avg, proj: fpts(avg)
      });
    });
    POOL.sort(function (a, b) { return b.proj - a.proj; });
    BY_ID = {};
    POOL.forEach(function (p) { BY_ID[p.id] = p; });
    return POOL;
  }
  function P(id) { pool(); return BY_ID[id]; }
  function fpts(line) {
    return line.points * WEIGHTS.points + line.rebounds * WEIGHTS.rebounds +
      line.assists * WEIGHTS.assists + line.steals * WEIGHTS.steals + line.blocks * WEIGHTS.blocks;
  }
  function fitsSlot(pos, slot) {
    if (slot === 'UTIL') return true;
    if (slot === 'G') return pos === 'G';
    if (slot === 'F') return pos === 'F' || pos === 'C';
    return false;
  }

  // ── League creation ─────────────────────────────────────
  function createLeague(opts) {
    var n = opts.numTeams;
    var teams = [];
    var names = BOT_NAMES.slice();
    var r = mulberry32(Date.now() >>> 0);
    for (var i = names.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)); var t = names[i]; names[i] = names[j]; names[j] = t; }
    for (var k = 0; k < n; k++) {
      teams.push({
        id: 't' + k, name: k === 0 ? (opts.teamName || sessionName() + "'s Team") : names[k - 1],
        isUser: k === 0, roster: []
      });
    }
    // Randomize draft order (user not always first)
    var order = teams.map(function (t) { return t.id; });
    for (var a = order.length - 1; a > 0; a--) { var b = Math.floor(r() * (a + 1)); var tmp = order[a]; order[a] = order[b]; order[b] = tmp; }
    var picks = [];
    for (var rd = 0; rd < opts.rosterSize; rd++) {
      var row = rd % 2 === 0 ? order.slice() : order.slice().reverse();
      picks = picks.concat(row);
    }
    state = {
      version: 1,
      phase: 'draft',
      league: {
        name: opts.name || 'Season League', numTeams: n, rosterSize: opts.rosterSize,
        weeks: opts.weeks, slots: SLOTS.slice(), weights: WEIGHTS, seed: (Date.now() % 1e9) | 0
      },
      teams: teams,
      draft: { order: picks, pick: 0, log: [] },
      schedule: buildSchedule(teams.map(function (t) { return t.id; }), opts.weeks),
      week: 0, day: 0,
      games: {}, lineups: {}, results: []
    };
    save();
  }

  // Circle-method round robin, cycled to fill the season.
  function buildSchedule(ids, weeks) {
    var list = ids.slice();
    if (list.length % 2) list.push(null);
    var n = list.length, rounds = [];
    for (var r = 0; r < n - 1; r++) {
      var pairs = [];
      for (var i = 0; i < n / 2; i++) {
        var a = list[i], b = list[n - 1 - i];
        if (a && b) pairs.push(r % 2 ? [b, a] : [a, b]);
      }
      rounds.push(pairs);
      list.splice(1, 0, list.pop());
    }
    var out = [];
    for (var w = 0; w < weeks; w++) out.push(rounds[w % rounds.length]);
    return out;
  }

  // ── Draft ───────────────────────────────────────────────
  function onClock() { return state.draft.order[state.draft.pick]; }
  function team(id) { for (var i = 0; i < state.teams.length; i++) if (state.teams[i].id === id) return state.teams[i]; }
  function userTeam() { return state.teams[0]; }
  function drafted() {
    var s = {};
    state.teams.forEach(function (t) { t.roster.forEach(function (id) { s[id] = true; }); });
    return s;
  }
  function available() {
    var d = drafted();
    return pool().filter(function (p) { return !d[p.id]; });
  }
  function makePick(teamId, playerId) {
    var t = team(teamId);
    t.roster.push(playerId);
    state.draft.log.push({ pick: state.draft.pick, teamId: teamId, playerId: playerId });
    state.draft.pick++;
    if (state.draft.pick >= state.draft.order.length) startSeason();
    save();
  }
  // Bot: best projection, but make sure the starting slots can be filled.
  function botChoose(teamId) {
    var t = team(teamId), avail = available();
    var g = 0, f = 0;
    t.roster.forEach(function (id) { var p = P(id); if (p.pos === 'G') g++; else f++; });
    var picksLeft = state.league.rosterSize - t.roster.length;
    var needG = Math.max(0, 2 - g), needF = Math.max(0, 2 - f);
    var r = rngFor('draft' + state.draft.pick);
    // Small jitter so bots don't draft identically every league
    var ranked = avail.map(function (p) { return { p: p, s: p.proj * (0.9 + r() * 0.2) }; })
      .sort(function (a, b) { return b.s - a.s; }).map(function (x) { return x.p; });
    if (needG + needF >= picksLeft) {
      var want = needG > 0 ? function (p) { return p.pos === 'G'; } : function (p) { return p.pos !== 'G'; };
      for (var i = 0; i < ranked.length; i++) if (want(ranked[i])) return ranked[i].id;
    }
    return ranked[0].id;
  }
  function simToUser() {
    while (state.phase === 'draft' && onClock() !== userTeam().id) makePick(onClock(), botChoose(onClock()));
  }

  // ── Season / weeks ──────────────────────────────────────
  function startSeason() {
    state.phase = 'season';
    state.week = 1;
    startWeek();
  }
  function startWeek() {
    state.day = 0;
    state.games[state.week] = generateWeekGames(state.week);
    state.lineups[state.week] = {};
    state.teams.forEach(function (t) {
      var prev = state.lineups[state.week - 1] && state.lineups[state.week - 1][t.id];
      var slots;
      if (t.isUser && prev) {
        // Carry last week's lineup forward for the user
        slots = prev.map(function (s) { return newSlot(s.slot, s.playerId); });
      } else {
        slots = autoLineup(t).map(function (pid, i) { return newSlot(SLOTS[i], pid); });
      }
      state.lineups[state.week][t.id] = slots;
    });
    save();
  }
  function newSlot(slot, playerId) {
    return { slot: slot, playerId: playerId, eligible: [], locked: null, pending: null };
  }
  // Best projected weekly output (proj × games this week), fill G,G,F,F then UTIL.
  function autoLineup(t) {
    var wk = state.games[state.week] || {};
    var scored = t.roster.map(function (id) {
      var g = (wk[id] || []).length;
      return { id: id, v: P(id).proj * g + P(id).proj * 0.01 };
    }).sort(function (a, b) { return b.v - a.v; });
    var used = {}, out = [];
    SLOTS.forEach(function (slot) {
      for (var i = 0; i < scored.length; i++) {
        var c = scored[i];
        if (!used[c.id] && fitsSlot(P(c.id).pos, slot)) { used[c.id] = true; out.push(c.id); return; }
      }
      out.push(null);
    });
    return out;
  }

  // Simulated weekly schedule + box scores. One school = one schedule.
  function generateWeekGames(week) {
    var bySchool = {};
    pool().forEach(function (p) { (bySchool[p.college] = bySchool[p.college] || []).push(p); });
    var games = {};
    Object.keys(bySchool).forEach(function (school) {
      var r = rngFor('w' + week + '|' + school);
      var x = r();
      var count = x < 0.15 ? 1 : x < 0.8 ? 2 : 3;
      var days = [0, 1, 2, 3, 4, 5, 6];
      for (var i = days.length - 1; i > 0; i--) { var j = Math.floor(r() * (i + 1)); var t = days[i]; days[i] = days[j]; days[j] = t; }
      days = days.slice(0, count).sort();
      bySchool[school].forEach(function (p) {
        var pr = rngFor('w' + week + '|' + p.id);
        games[p.id] = days.map(function (d) {
          var dnp = pr() < 0.05;
          var line = { points: 0, rebounds: 0, assists: 0, steals: 0, blocks: 0 };
          if (!dnp) {
            Object.keys(line).forEach(function (k) {
              var m = p.avg[k];
              var sd = m * 0.45 + (k === 'points' ? 1.5 : 0.5);
              line[k] = Math.max(0, Math.round(m + gauss(pr) * sd));
            });
          }
          return { day: d, line: line, fpts: Math.round(fpts(line) * 10) / 10, dnp: dnp };
        });
      });
    });
    return games;
  }
  function gamesFor(pid, week) { return ((state.games[week || state.week] || {})[pid]) || []; }
  function gameOn(pid, day) {
    var g = gamesFor(pid);
    for (var i = 0; i < g.length; i++) if (g[i].day === day) return g[i];
    return null;
  }
  function slotsOf(teamId, week) { return state.lineups[week || state.week][teamId]; }

  // Play one day: every unlocked starter who plays that day gets an
  // eligible game; that game becomes the pending lock decision.
  function simDay() {
    if (state.day > 6) return;
    var d = state.day;
    state.teams.forEach(function (t) {
      slotsOf(t.id).forEach(function (s) {
        if (s.locked || !s.playerId) return;
        var g = gameOn(s.playerId, d);
        if (g) {
          var rec = { playerId: s.playerId, day: d, fpts: g.fpts, dnp: g.dnp };
          s.eligible.push(rec);
          s.pending = rec;
        }
      });
      if (!t.isUser) botDecide(t);
    });
    state.day++;
    if (state.day > 6) finalizeWeek();
    save();
  }
  function lockSlot(teamId, idx) {
    var s = slotsOf(teamId)[idx];
    if (!s || s.locked || !s.pending) return;
    s.locked = s.pending; s.pending = null;
    save();
  }
  function passSlot(teamId, idx) {
    var s = slotsOf(teamId)[idx];
    if (!s || s.locked) return;
    s.pending = null;
    save();
  }
  function remainingGames(pid, fromDay) {
    return gamesFor(pid).filter(function (g) { return g.day >= fromDay; }).length;
  }
  // Bot policy: lock a strong game, or lock when no games remain.
  function botDecide(t) {
    slotsOf(t.id).forEach(function (s, i) {
      if (s.locked || !s.pending) return;
      var p = P(s.pending.playerId);
      var left = remainingGames(s.playerId, state.day + 1);
      if (left === 0 || s.pending.fpts >= p.proj * 1.15) lockSlot(t.id, i);
      else s.pending = null;
    });
  }
  function slotScore(s) {
    if (s.locked) return { v: s.locked.fpts, kind: 'locked' };
    if (s.eligible.length) return { v: s.eligible[s.eligible.length - 1].fpts, kind: 'live' };
    return { v: 0, kind: 'none' };
  }
  function teamScore(teamId, week) {
    return slotsOf(teamId, week).reduce(function (sum, s) { return sum + slotScore(s).v; }, 0);
  }
  function finalizeWeek() {
    state.teams.forEach(function (t) {
      slotsOf(t.id).forEach(function (s) {
        if (!s.locked && s.eligible.length) s.locked = Object.assign({ auto: true }, s.eligible[s.eligible.length - 1]);
        s.pending = null;
      });
    });
    state.schedule[state.week - 1].forEach(function (m) {
      state.results.push({
        week: state.week, home: m[0], away: m[1],
        homePts: Math.round(teamScore(m[0]) * 10) / 10, awayPts: Math.round(teamScore(m[1]) * 10) / 10
      });
    });
  }
  function nextWeek() {
    if (state.day <= 6) return;
    if (state.week >= state.league.weeks) { state.phase = 'done'; save(); return; }
    state.week++;
    startWeek();
  }
  function swapInto(idx, pid) {
    var slots = slotsOf(userTeam().id);
    var s = slots[idx];
    if (!s || s.locked) return;
    // If that player already starts elsewhere, swap them (only if that slot is unlocked and fits)
    for (var i = 0; i < slots.length; i++) {
      if (i !== idx && slots[i].playerId === pid) {
        if (slots[i].locked || (s.playerId && !fitsSlot(P(s.playerId).pos, slots[i].slot))) return;
        slots[i].playerId = s.playerId; slots[i].pending = null;
      }
    }
    s.playerId = pid; s.pending = null;
    save();
  }
  function opponentOf(teamId, week) {
    var w = state.schedule[(week || state.week) - 1] || [];
    for (var i = 0; i < w.length; i++) {
      if (w[i][0] === teamId) return w[i][1];
      if (w[i][1] === teamId) return w[i][0];
    }
    return null;
  }
  function standings() {
    var rows = {};
    state.teams.forEach(function (t) { rows[t.id] = { id: t.id, name: t.name, isUser: t.isUser, w: 0, l: 0, t: 0, pf: 0, pa: 0 }; });
    state.results.forEach(function (r) {
      var h = rows[r.home], a = rows[r.away];
      h.pf += r.homePts; h.pa += r.awayPts; a.pf += r.awayPts; a.pa += r.homePts;
      if (r.homePts > r.awayPts) { h.w++; a.l++; } else if (r.homePts < r.awayPts) { a.w++; h.l++; } else { h.t++; a.t++; }
    });
    return Object.keys(rows).map(function (k) { return rows[k]; })
      .sort(function (a, b) { return (b.w + b.t / 2) - (a.w + a.t / 2) || b.pf - a.pf; });
  }
  function seasonPoints(pid) {
    var total = 0, gp = 0;
    Object.keys(state.games).forEach(function (w) {
      (state.games[w][pid] || []).forEach(function (g) {
        if (+w < state.week || g.day < state.day) { total += g.fpts; gp++; }
      });
    });
    return { total: total, gp: gp };
  }

  // ── Rendering ───────────────────────────────────────────
  //  Full re-render on every action (cheap at this size). Motion is
  //  applied deliberately: the view fades in only when the view/tab
  //  changes, and a lock gets a one-time "stamp" on that slot.
  var ICON = {
    back: '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M12.5 4.5 7 10l5.5 5.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    lock: '<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="3" y="7" width="10" height="7" rx="1.6" fill="currentColor"/><path d="M5.2 7V5.2a2.8 2.8 0 0 1 5.6 0V7" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>',
    swap: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 5h8l-2.2-2.2M12 11H4l2.2 2.2" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    search: '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="7" cy="7" r="4.5" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="m10.5 10.5 3 3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>'
  };
  var lastViewKey = '';

  function render() {
    if (!root) return;
    var html, key;
    if (!state) { html = viewSetup(); key = 'setup'; }
    else if (state.phase === 'draft') { html = viewDraft(); key = 'draft'; }
    else { html = viewSeason(); key = 'season-' + ui.tab; }
    var enter = key !== lastViewKey;
    lastViewKey = key;
    var y = window.scrollY;
    root.innerHTML =
      '<div class="ss-wrap' + (key === 'draft' ? ' ss-wide' : '') + '">' +
        '<header class="ss-top">' +
          '<button class="ss-back" data-act="exit">' + ICON.back + '<span>Leagues</span></button>' +
          '<h1 class="ss-league">' + esc(state ? state.league.name : 'New league') + '</h1>' +
          '<span class="ss-lab" title="Offline lab build. Games are simulated.">Lab</span>' +
        '</header>' +
        '<main class="ss-main' + (enter ? ' ss-enter' : '') + '">' + html + '</main>' +
        (ui.toast ? '<div class="ss-toast" role="status">' + esc(ui.toast) + '</div>' : '') +
      '</div>';
    ui.toast = '';
    ui.stamp = null;
    if (enter) window.scrollTo(0, 0); else window.scrollTo(0, y);
  }

  function chips(key, values, current, suffix) {
    return '<div class="ss-chips" role="radiogroup">' + values.map(function (v) {
      var on = v === current;
      return '<button type="button" role="radio" aria-checked="' + on + '" class="ss-chip' + (on ? ' on' : '') +
        '" data-act="opt" data-k="' + key + '" data-v="' + v + '">' + v + (suffix ? '<small>' + suffix + '</small>' : '') + '</button>';
    }).join('') + '</div>';
  }

  function viewSetup() {
    var s = ui.setup;
    var picks = s.teams * s.roster;
    return '<section class="ss-setup">' +
      '<h2 class="ss-display">Set up your season</h2>' +
      '<p class="ss-lede">Draft a roster, start five each week, and lock in the games you want to count.</p>' +
      '<div class="ss-form">' +
        '<label class="ss-field"><span>League name</span><input id="ssName" type="text" maxlength="40" value="' + esc(s.name) + '" /></label>' +
        '<label class="ss-field"><span>Your team</span><input id="ssTeam" type="text" maxlength="30" value="' + esc(s.team) + '" /></label>' +
        '<div class="ss-field"><span>Teams</span>' + chips('teams', [4, 6, 8, 10, 12], s.teams) + '</div>' +
        '<div class="ss-field"><span>Players per roster</span>' + chips('roster', [8, 9, 10, 11, 12], s.roster) + '</div>' +
        '<div class="ss-field"><span>Regular season length</span>' + chips('weeks', [6, 8, 10, 12, 14, 16], s.weeks, 'wk') + '</div>' +
      '</div>' +
      '<p class="ss-summary">' + s.teams + ' teams draft ' + picks + ' players over ' + s.roster + ' rounds, then play ' + s.weeks + ' weekly matchups.</p>' +
      '<dl class="ss-rules">' +
        '<div><dt>Starters</dt><dd>G, G, F, F and a utility spot. Everyone else sits on your bench.</dd></div>' +
        '<div><dt>Lock-in</dt><dd>After a starter plays, lock that score for the week or pass and wait for his next game. Locks are final.</dd></div>' +
        '<div><dt>No lock</dt><dd>The slot keeps its most recent game. A DNP scores zero.</dd></div>' +
        '<div><dt>Matchups</dt><dd>One opponent a week. Standings go by record, then total points.</dd></div>' +
      '</dl>' +
      '<button class="ss-btn ss-btn-primary ss-btn-block" data-act="create">Start the draft</button>' +
      '<p class="ss-fine">In the lab, the other teams are bots and games are simulated from real 2025–26 averages.</p>' +
    '</section>';
  }

  function posTag(pos) { return '<span class="ss-pos ss-pos-' + pos + '" aria-label="' + pos + '">' + pos + '</span>'; }
  function playerCell(p, meta) {
    return '<div class="ss-pl">' + posTag(p.pos) +
      '<div class="ss-pl-txt"><span class="ss-pl-name">' + esc(p.name) + (p.fresh ? '<span class="ss-fr" title="No prior college stats">FR</span>' : '') + '</span>' +
      '<span class="ss-pl-meta"><span>' + esc(p.college) + '</span>' + (meta ? '<span>' + meta + '</span>' : '') + '</span></div></div>';
  }

  function viewDraft() {
    var d = state.draft, n = state.league.numTeams;
    var round = Math.floor(d.pick / n) + 1, inRound = (d.pick % n) + 1;
    var clock = team(onClock());
    var mine = clock.isUser;
    var u = userTeam();
    var nextUser = -1;
    for (var i = d.pick; i < d.order.length; i++) if (d.order[i] === u.id) { nextUser = i; break; }
    var away = nextUser - d.pick;
    var pct = Math.round(d.pick / d.order.length * 100);

    var list = available().filter(function (p) {
      if (ui.filterPos !== 'ALL' && p.pos !== ui.filterPos && !(ui.filterPos === 'F' && p.pos === 'C')) return false;
      if (ui.search && (p.name + ' ' + p.college).toLowerCase().indexOf(ui.search.toLowerCase()) < 0) return false;
      return true;
    }).slice(0, 60);

    var recent = d.log.slice(-5).reverse().map(function (l, k) {
      var p = P(l.playerId), t = team(l.teamId);
      return '<li class="' + (k === 0 ? 'fresh' : '') + '"><span class="ss-pk">' + (l.pick + 1) + '</span><span class="ss-feed-txt"><b>' + esc(p.name) + '</b><span>' + esc(t.name) + '</span></span></li>';
    }).join('') || '<li class="ss-empty">The first pick will show here.</li>';

    var g = 0, f = 0; u.roster.forEach(function (id) { if (P(id).pos === 'G') g++; else f++; });
    var slotsLeft = state.league.rosterSize - u.roster.length;
    var myRoster = u.roster.map(function (id) {
      var p = P(id);
      return '<li>' + posTag(p.pos) + '<span class="ss-mini-name">' + esc(p.name) + '</span><span class="ss-num">' + f1(p.proj) + '</span></li>';
    }).join('');
    for (var e = 0; e < slotsLeft; e++) myRoster += '<li class="ss-open-slot"><span class="ss-pos ss-pos-x"></span><span>Open</span></li>';
    if (!u.roster.length) myRoster = '<li class="ss-empty ss-roster-empty">Your picks will show here.</li>' + myRoster;

    var needs = (g < 2 ? (2 - g) + ' more guard' + (2 - g > 1 ? 's' : '') : '') + (g < 2 && f < 2 ? ' and ' : '') +
      (f < 2 ? (2 - f) + ' more forward' + (2 - f > 1 ? 's' : '') : '');

    return '<section class="ss-clock' + (mine ? ' is-mine' : '') + '">' +
        '<div class="ss-clock-txt">' +
          '<span class="ss-clock-meta">Round ' + round + ', pick ' + inRound + '</span>' +
          '<span class="ss-clock-who">' + (mine ? 'You’re on the clock' : esc(clock.name) + ' is picking') + '</span>' +
          (!mine && away > 0 ? '<span class="ss-clock-meta">You pick in ' + away + '</span>' : '') +
        '</div>' +
        (mine ? '<button class="ss-btn ss-btn-ghost" data-act="autopick">Auto-pick</button>'
              : '<button class="ss-btn ss-btn-primary" data-act="simdraft">Skip to my pick</button>') +
        '<div class="ss-progress" aria-hidden="true"><span style="width:' + pct + '%"></span></div>' +
      '</section>' +
      '<div class="ss-draft">' +
        '<section class="ss-board-pane">' +
          '<div class="ss-tools">' +
            '<label class="ss-search">' + ICON.search + '<input id="ssSearch" type="search" placeholder="Search players or schools" value="' + esc(ui.search) + '" aria-label="Search players" /></label>' +
            '<div class="ss-seg" role="tablist">' + [['ALL', 'All'], ['G', 'G'], ['F', 'F'], ['C', 'C']].map(function (x) {
              return '<button role="tab" aria-selected="' + (ui.filterPos === x[0]) + '" data-act="pos" data-pos="' + x[0] + '" class="' + (ui.filterPos === x[0] ? 'on' : '') + '">' + x[1] + '</button>';
            }).join('') + '</div>' +
          '</div>' +
          '<div class="ss-list-head"><span>Player</span><span>Fantasy pts / game</span></div>' +
          '<ul class="ss-list">' + (list.map(function (p) {
            return '<li>' + playerCell(p, esc(p.cls || '')) +
              '<span class="ss-proj ss-num">' + f1(p.proj) + '</span>' +
              (mine ? '<button class="ss-btn ss-btn-draft" data-act="pick" data-id="' + p.id + '" aria-label="Draft ' + esc(p.name) + '">Draft</button>' : '') + '</li>';
          }).join('') || '<li class="ss-empty">No players match that search.</li>') + '</ul>' +
        '</section>' +
        '<aside class="ss-side-pane">' +
          '<section class="ss-panel"><h3 class="ss-h3">Your roster<span class="ss-count">' + u.roster.length + ' of ' + state.league.rosterSize + '</span></h3>' +
            '<ul class="ss-mini">' + myRoster + '</ul>' +
            (needs ? '<p class="ss-hint">Starters need ' + needs + '.</p>' : '') + '</section>' +
          '<section class="ss-panel"><h3 class="ss-h3">Latest picks</h3><ol class="ss-feed">' + recent + '</ol></section>' +
        '</aside>' +
      '</div>';
  }

  function viewSeason() {
    var tabs = [['week', 'Lineup'], ['matchup', 'Matchup'], ['standings', 'Standings'], ['roster', 'Roster']];
    var body = ui.tab === 'matchup' ? viewMatchup() : ui.tab === 'standings' ? viewStandings() :
      ui.tab === 'roster' ? viewRoster() : viewWeek();
    var showBoard = ui.tab === 'week' || ui.tab === 'matchup';
    return (state.phase === 'done' ? viewChampion() : '') +
      (showBoard ? scoreboard() : '') +
      '<nav class="ss-tabs" role="tablist">' + tabs.map(function (t) {
        return '<button role="tab" aria-selected="' + (ui.tab === t[0]) + '" data-act="tab" data-tab="' + t[0] + '" class="' + (ui.tab === t[0] ? 'on' : '') + '">' + t[1] + '</button>';
      }).join('') + '</nav>' + '<div class="ss-tabbody">' + body + '</div>';
  }

  function viewChampion() {
    var s = standings()[0], mine = s.isUser;
    return '<section class="ss-champ">' +
      '<span class="ss-champ-k">Final standings</span>' +
      '<span class="ss-champ-name">' + (mine ? 'You won the league' : esc(s.name) + ' won the league') + '</span>' +
      '<span class="ss-champ-rec">' + s.w + '–' + s.l + (s.t ? '–' + s.t : '') + ', ' + f1(s.pf) + ' points for</span>' +
      '<button class="ss-btn ss-btn-ghost" data-act="reset">Start a new season</button></section>';
  }

  function scoreboard() {
    var u = userTeam(), oppId = opponentOf(u.id), opp = oppId ? team(oppId) : null;
    var my = teamScore(u.id), their = opp ? teamScore(opp.id) : 0;
    var total = my + their;
    var share = total ? Math.round(my / total * 100) : 50;
    var weekOver = state.day > 6;
    var ctrl = '';
    if (state.phase !== 'done') {
      if (weekOver) ctrl = '<button class="ss-btn ss-btn-primary" data-act="nextweek">' + (state.week >= state.league.weeks ? 'See final standings' : 'Start week ' + (state.week + 1)) + '</button>';
      else ctrl = '<button class="ss-btn ss-btn-primary" data-act="simday">Play ' + DAYS_FULL[state.day] + '</button>' +
        '<button class="ss-btn ss-btn-ghost" data-act="simweek">Play the rest of the week</button>';
    }
    var lead = my === their ? '' : my > their ? 'me' : 'them';
    return '<section class="ss-scoreboard">' +
      '<div class="ss-sb-head"><span>Week ' + state.week + ' of ' + state.league.weeks + (weekOver ? ', final' : '') + '</span>' +
        '<ol class="ss-days" aria-label="Days this week">' + DAYS.map(function (d, i) {
          var st = i < state.day ? 'done' : i === state.day && !weekOver ? 'now' : '';
          return '<li class="' + st + '"' + (st === 'now' ? ' aria-current="step"' : '') + '>' + d.charAt(0) + '<span class="sr">' + DAYS_FULL[i] + '</span></li>';
        }).join('') + '</ol></div>' +
      '<div class="ss-sb-teams">' +
        '<div class="ss-sb-side' + (lead === 'me' ? ' lead' : '') + '"><span class="ss-sb-name">' + esc(u.name) + '</span><span class="ss-sb-pts">' + f1(my) + '</span></div>' +
        '<div class="ss-sb-side r' + (lead === 'them' ? ' lead' : '') + '"><span class="ss-sb-name">' + (opp ? esc(opp.name) : 'Bye week') + '</span><span class="ss-sb-pts">' + f1(their) + '</span></div>' +
      '</div>' +
      '<div class="ss-sb-bar" role="img" aria-label="Your share of points: ' + share + '%"><span style="width:' + share + '%"></span></div>' +
      (ctrl ? '<div class="ss-sb-ctrl">' + ctrl + '</div>' : '') +
    '</section>';
  }

  function gameDots(pid, slotRec) {
    var g = gamesFor(pid);
    if (!g.length) return '<div class="ss-games"><span class="ss-games-none">No games this week</span></div>';
    return '<div class="ss-games">' + g.map(function (x) {
      var played = x.day < state.day;
      var isLocked = slotRec && slotRec.locked && slotRec.locked.playerId === pid && slotRec.locked.day === x.day;
      var cls = isLocked ? 'lk' : played ? 'pl' : 'up';
      return '<span class="ss-game ' + cls + '"><span class="d">' + DAYS[x.day] + '</span>' +
        (played ? '<span class="v">' + (x.dnp ? 'DNP' : f1(x.fpts)) + '</span>' : '') + '</span>';
    }).join('') + '</div>';
  }

  function slotStatus(s, idx) {
    if (!s.playerId) return '<div class="ss-st"><span class="ss-st-note">Empty</span></div>';
    var stamp = ui.stamp === idx ? ' stamp' : '';
    if (s.locked) {
      var who = s.locked.playerId !== s.playerId ? ', ' + esc(P(s.locked.playerId).name) : '';
      return '<div class="ss-st locked' + stamp + '"><span class="ss-st-label">' + ICON.lock + (s.locked.auto ? 'Final' : 'Locked') + '</span>' +
        '<span class="ss-st-pts">' + f1(s.locked.fpts) + '</span><span class="ss-st-note">' + DAYS_FULL[s.locked.day] + who + '</span></div>';
    }
    var left = remainingGames(s.playerId, state.day);
    if (s.pending) {
      return '<div class="ss-st pending"><span class="ss-st-label">' + DAYS_FULL[s.pending.day] + '</span>' +
        '<span class="ss-st-pts">' + (s.pending.dnp ? '0.0' : f1(s.pending.fpts)) + '</span>' +
        '<span class="ss-st-note">' + (s.pending.dnp ? 'Did not play. ' : '') + (left ? left + ' more game' + (left > 1 ? 's' : '') + ' this week' : 'Last game this week, so it counts') + '</span>' +
        '<div class="ss-lp"><button class="ss-btn ss-btn-lock" data-act="lock" data-i="' + idx + '">' + ICON.lock + 'Lock</button>' +
        (left ? '<button class="ss-btn ss-btn-ghost ss-btn-sm" data-act="pass" data-i="' + idx + '">Pass</button>' : '') + '</div></div>';
    }
    var sc = slotScore(s);
    if (sc.kind === 'live') {
      return '<div class="ss-st live"><span class="ss-st-label">Holding</span><span class="ss-st-pts">' + f1(sc.v) + '</span>' +
        '<span class="ss-st-note">' + (left ? 'Counts unless you lock a later game' : 'No games left, so this counts') + '</span></div>';
    }
    return '<div class="ss-st idle"><span class="ss-st-note">' + (left ? 'Next game ' + DAYS_FULL[nextGameDay(s.playerId)] : 'No games left. This slot scores zero.') + '</span></div>';
  }
  function nextGameDay(pid) {
    var g = gamesFor(pid).filter(function (x) { return x.day >= state.day; });
    return g.length ? g[0].day : 0;
  }

  function viewWeek() {
    var u = userTeam(), slots = slotsOf(u.id);
    var starters = {}; slots.forEach(function (s) { if (s.playerId) starters[s.playerId] = true; });
    var bench = u.roster.filter(function (id) { return !starters[id]; });
    var open = ui.swapSlot;
    var decisions = slots.filter(function (s) { return s.pending && !s.locked; }).length;

    var rows = slots.map(function (s, i) {
      var p = s.playerId ? P(s.playerId) : null;
      var canSwap = !s.locked && state.phase !== 'done';
      var state_ = s.locked ? 'is-locked' : s.pending ? 'is-pending' : '';
      var swapList = '';
      if (open === i && canSwap) {
        var cands = u.roster.filter(function (id) { return id !== s.playerId && fitsSlot(P(id).pos, s.slot); })
          .filter(function (id) {
            for (var k = 0; k < slots.length; k++) if (slots[k].playerId === id && slots[k].locked) return false;
            return true;
          });
        swapList = '<div class="ss-swap"><span class="ss-swap-h">Move into the ' + (s.slot === 'UTIL' ? 'utility' : s.slot) + ' slot</span><ul>' + (cands.map(function (id) {
          var q = P(id), left = remainingGames(id, state.day);
          return '<li><button data-act="swapto" data-i="' + i + '" data-id="' + id + '">' + playerCell(q, left + ' game' + (left === 1 ? '' : 's') + ' left') +
            (starters[id] ? '<span class="ss-tag">Starting</span>' : '') + '</button></li>';
        }).join('') || '<li class="ss-empty">Nobody on your roster fits this slot.</li>') + '</ul></div>';
      }
      return '<li class="ss-slot ' + state_ + '">' +
        '<span class="ss-slot-k">' + (s.slot === 'UTIL' ? 'UTL' : s.slot) + '</span>' +
        '<div class="ss-slot-main">' +
          (p ? playerCell(p, f1(p.proj) + ' proj') : '<span class="ss-empty">Empty slot</span>') +
          (p ? gameDots(p.id, s) : '') +
        '</div>' +
        slotStatus(s, i) +
        (canSwap ? '<button class="ss-link ss-slot-swap" data-act="swap" data-i="' + i + '" aria-expanded="' + (open === i) + '">' + ICON.swap + (open === i ? 'Cancel' : 'Swap player') + '</button>' : '') +
        swapList +
      '</li>';
    }).join('');

    var benchRows = bench.map(function (id) {
      var p = P(id);
      return '<li>' + playerCell(p, f1(p.proj) + ' proj') + gameDots(id, null) + '</li>';
    }).join('') || '<li class="ss-empty">Everyone on your roster is starting.</li>';

    return '<section class="ss-panel ss-lineup">' +
        '<h3 class="ss-h3">Starters' + (decisions ? '<span class="ss-count hot">' + decisions + ' to decide</span>' : '') + '</h3>' +
        '<ul class="ss-slots">' + rows + '</ul>' +
        '<p class="ss-hint">Lock a score to keep it. Pass to wait for his next game. If you never lock, the slot keeps its most recent game.</p>' +
      '</section>' +
      '<section class="ss-panel"><h3 class="ss-h3">Bench<span class="ss-count">Bench games don’t count</span></h3><ul class="ss-bench">' + benchRows + '</ul></section>';
  }

  function viewMatchup() {
    var u = userTeam(), oppId = opponentOf(u.id);
    if (!oppId) return '<section class="ss-panel"><p class="ss-empty">You have a bye this week.</p></section>';
    var a = slotsOf(u.id), b = slotsOf(oppId);
    function cell(s, right) {
      if (!s.playerId) return '<div class="ss-mc' + (right ? ' r' : '') + '"><span class="ss-empty">Empty</span></div>';
      var sc = slotScore(s), p = P(s.playerId);
      return '<div class="ss-mc' + (right ? ' r' : '') + '"><span class="ss-mc-name">' + esc(p.name) + '</span><span class="ss-mc-school">' + esc(p.college) + '</span>' +
        '<span class="ss-mc-pts ' + sc.kind + '">' + (sc.kind === 'locked' ? ICON.lock : '') + f1(sc.v) + '</span></div>';
    }
    var rows = a.map(function (s, i) {
      var va = slotScore(s).v, vb = slotScore(b[i]).v;
      return '<li class="' + (va > vb ? 'win-a' : vb > va ? 'win-b' : '') + '">' + cell(s, false) + '<span class="ss-mslot">' + (s.slot === 'UTIL' ? 'UTL' : s.slot) + '</span>' + cell(b[i], true) + '</li>';
    }).join('');
    var past = state.results.filter(function (r) { return r.home === u.id || r.away === u.id; }).slice().reverse().map(function (r) {
      var me = r.home === u.id, mp = me ? r.homePts : r.awayPts, op = me ? r.awayPts : r.homePts;
      var o = team(me ? r.away : r.home);
      var res = mp > op ? 'W' : mp < op ? 'L' : 'T';
      return '<li><span class="ss-res ' + res + '">' + res + '</span><span class="ss-res-txt">Week ' + r.week + ' vs ' + esc(o.name) + '</span><span class="ss-num">' + f1(mp) + '–' + f1(op) + '</span></li>';
    }).join('') || '<li class="ss-empty">Finished weeks will show here.</li>';
    return '<section class="ss-panel"><div class="ss-mhead"><span>' + esc(u.name) + '</span><span>' + esc(team(oppId).name) + '</span></div><ul class="ss-mrows">' + rows + '</ul></section>' +
      '<section class="ss-panel"><h3 class="ss-h3">Your results</h3><ul class="ss-results">' + past + '</ul></section>';
  }

  function viewStandings() {
    var rows = standings().map(function (r, i) {
      return '<tr class="' + (r.isUser ? 'me' : '') + '"><td class="rk">' + (i + 1) + '</td><td class="nm">' + esc(r.name) + '</td><td>' + r.w + '–' + r.l + (r.t ? '–' + r.t : '') +
        '</td><td>' + f1(r.pf) + '</td><td class="pa">' + f1(r.pa) + '</td></tr>';
    }).join('');
    var wk = state.week;
    var games = state.schedule[wk - 1].map(function (m) {
      var a = teamScore(m[0]), b = teamScore(m[1]);
      return '<li><span class="' + (a > b ? 'w' : '') + '">' + esc(team(m[0]).name) + '</span><span class="ss-num ' + (a > b ? 'w' : '') + '">' + f1(a) + '</span>' +
        '<span class="ss-num ' + (b > a ? 'w' : '') + '">' + f1(b) + '</span><span class="' + (b > a ? 'w' : '') + '">' + esc(team(m[1]).name) + '</span></li>';
    }).join('');
    return '<section class="ss-panel"><table class="ss-table"><caption class="sr">Standings</caption><thead><tr><th class="rk">#</th><th class="nm">Team</th><th>Record</th><th>For</th><th class="pa">Against</th></tr></thead><tbody>' + rows + '</tbody></table></section>' +
      '<section class="ss-panel"><h3 class="ss-h3">Week ' + wk + ' scores</h3><ul class="ss-scores">' + games + '</ul></section>';
  }

  function viewRoster() {
    var u = userTeam();
    var rows = u.roster.slice().sort(function (a, b) { return seasonPoints(b).total - seasonPoints(a).total; }).map(function (id) {
      var p = P(id), sp = seasonPoints(id);
      return '<tr><td class="nm">' + playerCell(p, esc(p.cls || '')) + '</td><td>' + sp.gp + '</td><td>' + (sp.gp ? f1(sp.total / sp.gp) : '–') + '</td><td>' + f1(sp.total) + '</td></tr>';
    }).join('');
    return '<section class="ss-panel"><table class="ss-table ss-rost"><caption class="sr">Your roster</caption><thead><tr><th class="nm">' + esc(u.name) + '</th><th>Games</th><th>Avg</th><th>Total</th></tr></thead><tbody>' + rows + '</tbody></table>' +
      '<p class="ss-hint">Scoring: 1 per point, 1.2 per rebound, 1.5 per assist, 2 per steal or block. Free agency and trades come later.</p></section>' +
      '<div class="ss-danger"><button class="ss-btn ss-btn-quiet" data-act="reset">Delete this league</button></div>';
  }

  // ── Events ──────────────────────────────────────────────
  function onClick(e) {
    var el = e.target.closest('[data-act]');
    if (!el || !root.contains(el)) return;
    var act = el.getAttribute('data-act');
    var i = +el.getAttribute('data-i');
    switch (act) {
      case 'exit': close(); return;
      case 'create':
        createLeague({
          name: ui.setup.name.trim() || 'Season league', teamName: ui.setup.team.trim(),
          numTeams: ui.setup.teams, rosterSize: ui.setup.roster, weeks: ui.setup.weeks
        });
        simToUser();
        break;
      case 'opt': ui.setup[el.getAttribute('data-k')] = +el.getAttribute('data-v'); break;
      case 'pos': ui.filterPos = el.getAttribute('data-pos'); break;
      case 'pick': makePick(userTeam().id, el.getAttribute('data-id')); ui.search = ''; simToUser(); break;
      case 'autopick': makePick(userTeam().id, botChoose(userTeam().id)); simToUser(); break;
      case 'simdraft': simToUser(); break;
      case 'tab': ui.tab = el.getAttribute('data-tab'); ui.swapSlot = null; break;
      case 'simday': simDay(); break;
      case 'simweek':
        // Stop at the next day with a decision so the user still gets to choose
        var startDay = state.day;
        do { simDay(); } while (state.day <= 6 && !hasPending());
        if (state.day <= 6) ui.toast = 'Paused after ' + DAYS_FULL[state.day - 1] + '. You have a lock decision.';
        if (state.day === startDay) ui.toast = '';
        break;
      case 'nextweek': nextWeek(); ui.swapSlot = null; break;
      case 'lock': lockSlot(userTeam().id, i); ui.stamp = i; break;
      case 'pass': passSlot(userTeam().id, i); break;
      case 'swap': ui.swapSlot = ui.swapSlot === i ? null : i; break;
      case 'swapto': swapInto(i, el.getAttribute('data-id')); ui.swapSlot = null; break;
      case 'reset':
        if (!el.classList.contains('confirm')) { el.classList.add('confirm'); el.textContent = 'Tap again to delete for good'; return; }
        state = null; try { localStorage.removeItem(STORE_KEY); } catch (er) { /* ignore */ }
        ui.tab = 'week';
        break;
    }
    render();
  }
  function hasPending() {
    return slotsOf(userTeam().id).some(function (s) { return s.pending && !s.locked; });
  }
  function onInput(e) {
    if (e.target.id === 'ssName') { ui.setup.name = e.target.value; return; }
    if (e.target.id === 'ssTeam') { ui.setup.team = e.target.value; return; }
    if (e.target.id === 'ssSearch') {
      ui.search = e.target.value;
      var pos = e.target.selectionStart;
      render();
      var el = document.getElementById('ssSearch');
      if (el) { el.focus(); try { el.setSelectionRange(pos, pos); } catch (er) { /* ignore */ } }
    }
  }
  function val(id) { var el = document.getElementById(id); return el ? el.value.trim() : ''; }

  // ── Open / close ────────────────────────────────────────
  var prevDisplay = null;
  function open() {
    root = document.getElementById('seasonApp');
    if (!root) return;
    state = load();
    ui.setup = { name: 'Season league', team: sessionName() === 'You' ? 'My team' : sessionName() + "'s team", teams: 8, roster: 10, weeks: 12 };
    lastViewKey = '';
    var splash = document.getElementById('splashScreen');
    if (splash) { prevDisplay = splash.style.display; splash.style.display = 'none'; }
    root.style.display = 'block';
    document.body.classList.add('ss-open');
    if (!root._wired) {
      root.addEventListener('click', onClick);
      root.addEventListener('input', onInput);
      root._wired = true;
    }
    render();
    window.scrollTo(0, 0);
  }
  function close() {
    if (root) root.style.display = 'none';
    document.body.classList.remove('ss-open');
    var splash = document.getElementById('splashScreen');
    if (splash) { splash.style.display = prevDisplay && prevDisplay !== 'none' ? prevDisplay : 'flex'; splash.style.opacity = ''; }
    renderSplashCard();
  }

  // ── League-type chooser on "+ Create League" ────────────
  //  Intercepts the splash button in the capture phase so app.js is
  //  untouched. "Tournament" re-fires the original click with a bypass
  //  flag; "Regular Season" opens this module.
  var bypass = false;
  function showModeChooser() {
    var bd = document.createElement('div');
    bd.className = 'mode-backdrop';
    bd.innerHTML =
      '<div class="mode-card" role="dialog" aria-modal="true" aria-labelledby="modeTitle">' +
        '<h3 id="modeTitle">Start a league</h3>' +
        '<p>Choose the format. Everyone who joins with your code plays the same one.</p>' +
        '<div class="mode-opts">' +
          '<button class="mode-opt" data-mode="tournament">' +
            '<svg class="mode-ic" viewBox="0 0 48 48" aria-hidden="true"><path d="M6 10h10v8h8M6 26h10v-8M6 30h10v8h8M6 46h10v-8M24 18v20h8v-10h10" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/></svg>' +
            '<b>Tournament</b><span>One draft, then players score until their team is knocked out.</span><i>March and in-season events</i></button>' +
          '<button class="mode-opt" data-mode="season">' +
            '<svg class="mode-ic" viewBox="0 0 48 48" aria-hidden="true"><rect x="6" y="9" width="36" height="32" rx="4" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M6 18h36M15 5v8M33 5v8" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><rect x="13" y="25" width="6" height="6" rx="1.5" fill="currentColor"/><rect x="29" y="25" width="6" height="6" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>' +
            '<b>Regular season</b><span>Draft 8 to 12 players and face a new opponent every week with lock-in scoring.</span><i>November through March</i></button>' +
        '</div>' +
        '<button class="mode-cancel" data-mode="cancel">Cancel</button>' +
      '</div>';
    document.body.appendChild(bd);
    requestAnimationFrame(function () { bd.classList.add('in'); });
    function onKey(ev) { if (ev.key === 'Escape') { finish('cancel'); } }
    document.addEventListener('keydown', onKey);
    function finish(mode) {
      document.removeEventListener('keydown', onKey);
      bd.remove();
      if (mode === 'tournament') {
        bypass = true;
        var btn = document.getElementById('createLeagueSplashBtn');
        if (btn) btn.click();
        bypass = false;
      } else if (mode === 'season') {
        open();
      }
    }
    bd.addEventListener('click', function (e) {
      var b = e.target.closest('[data-mode]');
      if (!b && e.target !== bd) return;
      finish(b ? b.getAttribute('data-mode') : 'cancel');
    });
    var first = bd.querySelector('.mode-opt');
    if (first) first.focus();
  }
  function renderSplashCard() {
    var slot = document.getElementById('seasonLeagueSlot');
    if (!slot) return;
    var s = load();
    if (!s) { slot.innerHTML = ''; return; }
    var sub = s.phase === 'draft' ? 'Drafting, pick ' + (s.draft.pick + 1) + ' of ' + s.draft.order.length :
      s.phase === 'done' ? 'Season complete' : 'Week ' + s.week + ' of ' + s.league.weeks;
    slot.innerHTML = '<button class="ss-splash-card" data-season-open="1"><span class="ss-splash-tag">Season</span>' +
      '<span class="ss-splash-txt"><b>' + esc(s.league.name) + '</b><span>' + esc(sub) + ', ' + s.league.numTeams + ' teams</span></span>' +
      '<span aria-hidden="true">&#8250;</span></button>';
  }
  function wireSplash() {
    document.addEventListener('click', function (e) {
      var create = e.target.closest && e.target.closest('#createLeagueSplashBtn');
      if (create && !bypass) {
        e.preventDefault(); e.stopImmediatePropagation();
        showModeChooser();
        return;
      }
      if (e.target.closest && e.target.closest('[data-season-open]')) open();
    }, true);
    var splash = document.getElementById('splashScreen');
    renderSplashCard();
    if (splash && window.MutationObserver) {
      new MutationObserver(function () { if (splash.style.display !== 'none') renderSplashCard(); })
        .observe(splash, { attributes: true, attributeFilter: ['style'] });
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wireSplash);
  else wireSplash();

  window.TipoffSeason = {
    open: open, close: close,
    // exposed for testing in the lab
    _debug: function () { return state; }
  };
})(window, document);
